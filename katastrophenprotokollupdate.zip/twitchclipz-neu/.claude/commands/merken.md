---
description: Schreibt neue Erkenntnisse in CLAUDE.md und sichert sie nach Google Drive
---

# Merken

Der Nutzer hat „merken" geschrieben, **oder** eine Arbeitssitzung geht zu
Ende, **oder** ein Meilenstein ist erreicht. Dann läuft dieser Ablauf —
auch ungefragt.

Der Zweck des ganzen Projekts steht in `CLAUDE.md` ganz oben, in seinen
Worten: *„Learning gemerkt, Fehler gemerkt, verbessert, immer aktueller
Stand ohne Befehl."* Dieser Befehl ist die Hälfte davon, die nicht von
allein läuft.

---

## Warum es diesen Umweg gibt

`git push` ist gesperrt (403, gemessen am 17.08.2026 auch mit angehängtem
Repo). Das Repo kann sich also **nicht selbst** fortschreiben.

Google Drive **ist** beschreibbar. Deshalb:

```
Repo CLAUDE.md  ──lädt automatisch──▶  Sitzung
                                         │
                                    (erweitern)
                                         │
Drive CLAUDE.md ◀──/merken schreibt──────┘
       │
       └──▶ nächste Sitzung liest per /neubeginn nach, was neuer ist
```

Drive ist damit die **lebende** Fassung, das Repo die Grundlage. Wenn die
beiden auseinanderlaufen, gewinnt die neuere — das ist fast immer Drive.

---

## Schritt 1 — Eintragen

Ergänze `CLAUDE.md` im Arbeitsverzeichnis um alles, was diese Sitzung
gebracht hat. **Ergänzen, nie überschreiben.** Was sich als falsch
erwiesen hat, wird durchgestrichen (`~~so~~`) und begründet — der Irrweg
ist Teil des Wissens.

Gehört hinein:
- **Gemessene Zahlen.** Retention, Aufrufe, Haltequote, Sekunde für
  Sekunde, wo der Hook sitzt und wo abgesprungen wird. Zahlen schlagen
  Vermutungen, immer.
- **Was schiefging und warum.** Der Fehler ist wertvoller als das
  Ergebnis, weil er sich sonst wiederholt.
- **Was ein Agentenlauf ergeben hat**, samt Widerspruch der beiden
  Agenten und dem, was sich durchgesetzt hat.
- **Was ausprobiert und verworfen wurde**, mit Begründung — sonst wird es
  in drei Wochen erneut ausprobiert.

Gehört **nicht** hinein: Vermutungen ohne Beleg, Zwischenstände, und
alles, was in der nächsten Sitzung ohnehin neu gemessen wird.

Trag das **laufend** ein, während gearbeitet wird. Schicken erst am Ende.

## Schritt 2 — Nach Drive sichern

Ziel ist der Google-Drive-Ordner `Katastrophenprotokoll-Pipeline`
(`1MFz5gNIBQfcXWBw8evnop_oUJ-9TnWtX`).

**Such die Datei über ihren Namen, nie über eine gemerkte ID** — beim
Ersetzen bekommt sie eine neue, und eine festgeschriebene ID zeigt danach
ins Leere:

1. `search_files` mit `parentId = '1MFz5gNIBQfcXWBw8evnop_oUJ-9TnWtX' and
   title = 'CLAUDE.md'`
2. `create_file` mit der neuen Fassung (`contentMimeType: text/markdown`,
   `disableConversionToGoogleType: true`)
3. `trash_file` auf die alte ID

**In dieser Reihenfolge.** Erst schreiben, dann wegräumen — bricht es in
der Mitte ab, ist lieber eine zu viel da als keine.

`update_file` ändert nur Metadaten und **nicht** den Inhalt. Es ist für
diesen Zweck nutzlos.

Wenn am Ende zwei `CLAUDE.md` im Ordner liegen, ist das ein Fehler: die
nächste Sitzung weiß dann nicht, welche gilt. Nachsehen und aufräumen.

## Schritt 3 — Dem Nutzer schicken

Schick ihm die Datei mit `SendUserFile`, damit er sie ins Repo laden kann.
Dazu **eine Zeile** in einfacher Sprache: was neu drinsteht, und dass er
sie bei GitHub per Ziehen-und-Ablegen ersetzen soll.

**Einmal am Ende, nicht tröpfeln.** Er hat ausdrücklich darum gebeten.

## Schritt 4 — Kurz melden

Zwei bis drei Sätze: was gelernt wurde, wo es jetzt steht. Keine
Aufzählung deiner Arbeitsschritte.

---

## Wenn Drive nicht erreichbar ist

Dann bleibt nur Schritt 3. Sag ihm in **einem** Satz deutlich, dass die
Sicherung diesmal nur über ihn läuft und die Erkenntnisse verloren gehen,
wenn er die Datei nicht hochlädt. Das ist der einzige Fall, in dem
Nachhaken angebracht ist.
