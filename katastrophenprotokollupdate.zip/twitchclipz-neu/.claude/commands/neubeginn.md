---
description: Bringt die Sitzung ohne Rückfragen auf den vollständigen Projektstand
---

# Neubeginn

Der Nutzer hat „neubeginn" geschrieben. Das heißt: **eine neue Sitzung hat
begonnen, und du sollst dich selbst auf den aktuellsten Stand bringen —
ohne dass er dir irgendetwas erklären muss.**

Arbeite die folgenden Schritte der Reihe nach ab. Frag zwischendurch
nichts. Melde dich erst am Ende, mit dem Ergebnis.

---

## Schritt 1 — Prüfen, ob das Fundament steht

Der Sitzungsstart-Hook (`.claude/hooks/session-start.sh`) hat bereits einen
Statusbericht ausgegeben. Lies ihn.

- **Pipeline unvollständig?** Dann ist das Repo nicht richtig angehängt.
  Sag dem Nutzer genau das, in einem Satz, und hör hier auf — alles Weitere
  wäre auf Sand gebaut.
- **Werkzeuge fehlen?** Installiere sie selbst nach (`ffmpeg`, `imagemagick`,
  `vosk`, `pillow`, `numpy`, `google-api-python-client`). Erwähne es nur,
  wenn es scheitert.
- **Kein Statusbericht erschienen?** Dann läuft der Hook nicht. Führe
  `bash .claude/hooks/session-start.sh` einmal von Hand aus.

## Schritt 2 — Das Gedächtnis lesen

`CLAUDE.md` ist bereits geladen. Verlass dich nicht darauf, dass du sie
„im Gefühl" hast — geh die Abschnitte **3 (Harte Lehren)**, **4 (Werkzeuge
und Zugänge)** und **5 (Stand)** wirklich durch. Dort steht, was schon
schiefgegangen ist. Der Sinn dieser Datei ist, dass es nicht zweimal
schiefgeht.

Achte besonders auf:
- Das Originalskript kommt **immer** vom Nutzer.
- Der Nutzer arbeitet **nicht** mit der Kommandozeile und kann keine
  `.md`-Dateien öffnen.
- Die Netzsperre ist eine Gästeliste. Was nicht drauf steht, ist zu.

## Schritt 3 — Den echten Kanalstand holen

Führe `python3 analyse.py` aus.

Das Skript zieht über die YouTube-API, was wirklich draußen ist: Abos,
Aufrufe, alle Videos mit Länge und Zahlen, welche Uploads terminiert sind,
und ob die Kanal-Standardsprache gesetzt ist.

- **Wenn es an fehlenden Zugangsdaten scheitert:** sag dem Nutzer in zwei
  Sätzen, was er in den Umgebungseinstellungen eintragen muss, und mach mit
  Schritt 4 weiter. Nicht blockieren.
- **Wenn es läuft:** die Zahlen aus `analyse.py` schlagen jede Zahl in
  `CLAUDE.md`. Gemessenes gewinnt gegen Notiertes, immer.

## Schritt 4 — Das Gedächtnis nachziehen

`git push` ist gesperrt. Die Vorsitzung konnte ihre Erkenntnisse deshalb
nicht ins Repo zurückschreiben — sie hat sie per `/merken` nach Google
Drive gesichert. **Dort steht möglicherweise mehr, als du gerade geladen
hast.**

Vergleiche `CLAUDE.md` im Drive-Ordner `Katastrophenprotokoll-Pipeline`
(`1MFz5gNIBQfcXWBw8evnop_oUJ-9TnWtX`) mit der geladenen Fassung. **Such
sie über den Namen, nicht über eine ID** — beim Sichern bekommt sie jedes
Mal eine neue.

- **Drive ist neuer oder größer?** Lies sie und arbeite ab jetzt mit ihr.
  Sag dem Nutzer in einem Satz, dass die Repo-Fassung hinterherhinkt und
  er sie bei Gelegenheit ersetzen sollte.
- **Beide gleich?** Nichts zu tun, nicht erwähnen.

Sieh im selben Ordner nach Dateien, die **neuer** sind als der letzte
Commit — dort legt der Nutzer Skripte, Voiceover und Bilder ab.

Ältere Drive-Dateien sind **kein** Wissen, sondern Altlast. `REGELN.md`,
`START-HIER.md` und die `LEARNINGS-*.md` stammen vom 15./16.08. und sind
von `CLAUDE.md` überholt; sie widersprechen ihr an mehreren Stellen (etwa
Untertitelgröße 42 statt 104). **Bei jedem Widerspruch gilt die
neuere `CLAUDE.md`, nie eine der alten Dateien.**

## Schritt 5 — Melden

Fasse in **höchstens 15 Zeilen** zusammen, in einfacher Sprache:

1. **Kanalstand** — Abos, Aufrufe, Anzahl Videos, was terminiert ist
2. **Was zuletzt lief** — der Stand aus Abschnitt 5 der `CLAUDE.md`
3. **Was jetzt ansteht** — der nächste offene Punkt
4. **Was blockiert** — nur, wenn wirklich etwas blockiert

Keine Tabelle mit Häkchen, keine Aufzählung deiner Arbeitsschritte. Er will
wissen, wo das Projekt steht, nicht was du getan hast.

Wenn mehr als drei Dinge zu berichten sind, liefere eine Artifact-Seite und
schreib in den Chat nur die drei wichtigsten Sätze.

---

## Am Ende jeder Arbeitssitzung

`git push` ist gesperrt (403). Das Zurückschreiben läuft deshalb von Hand:

1. Trag neue Erkenntnisse **laufend** in `CLAUDE.md` ein — ergänzen, nie
   überschreiben. Was sich als falsch erwiesen hat, wird durchgestrichen
   und begründet.
2. Schick die aktualisierte `CLAUDE.md` **einmal am Ende** zum Hochladen.
   Nicht tröpfeln.
